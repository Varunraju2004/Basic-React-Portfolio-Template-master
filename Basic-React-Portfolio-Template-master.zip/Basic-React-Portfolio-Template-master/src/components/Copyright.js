function Copyright() {
  return (
    <div class="copyright py-4 text-center text-white">
            <div class="container"><small>Copyright &copy; Vandit Bera 2022</small></div>
        </div>
  )
}

export default Copyright